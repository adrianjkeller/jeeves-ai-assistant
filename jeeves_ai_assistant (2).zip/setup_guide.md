# 🧰 Jeeves Setup Guide

This guide walks you through setting up Jeeves, your full-stack AI assistant, on any new device or environment.

## 🖥 Requirements

- Git
- Docker OR Python 3.10+
- GitHub account
- API keys (OpenAI, Notion, Jira)

## 📦 Clone from GitHub

```bash
git clone https://github.com/YOUR_USERNAME/jeeves-ai-assistant.git
cd jeeves-ai-assistant
```

## 🐳 Docker

```bash
cp .env.example .env
docker build -t jeeves .
docker run -p 10000:10000 --env-file .env jeeves
```

## 🐍 Python (no Docker)

```bash
python -m venv venv
source venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
python main.py
```

## 📂 Files
- `main.py`
- `templates/index.html`
- `project_tracker.json` (auto-generated)
- `.env` (user-created)
