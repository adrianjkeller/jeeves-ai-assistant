# Jeeves: Flask Web App for Custom Assistant with OpenAI's Assistants API + Deployment

from flask import Flask, request, jsonify, render_template, send_from_directory, redirect
import openai
import time
import os
import json
import uuid
import requests
from notion_client import Client as NotionClient
from flask_login import LoginManager, login_user, login_required, logout_user, UserMixin

app = Flask(__name__)
app.secret_key = os.getenv("APP_SECRET_KEY", "supersecret")
openai.api_key = os.getenv("OPENAI_API_KEY")
NOTION_TOKEN = os.getenv("NOTION_API_KEY")
JIRA_API_URL = os.getenv("JIRA_API_URL")
JIRA_API_TOKEN = os.getenv("JIRA_API_TOKEN")

UPLOAD_FOLDER = "uploads"
PROJECTS_FILE = "project_tracker.json"
os.makedirs(UPLOAD_FOLDER, exist_ok=True)
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

notion = NotionClient(auth=NOTION_TOKEN)
login_manager = LoginManager()
login_manager.init_app(app)

# --- User Auth ---
class User(UserMixin):
    def __init__(self, id):
        self.id = id

@login_manager.user_loader
def load_user(user_id):
    return User(user_id)

@app.route("/login", methods=["POST"])
def login():
    data = request.get_json()
    username = data.get("username")
    password = data.get("password")
    if username == os.getenv("ADMIN_USERNAME") and password == os.getenv("ADMIN_PASSWORD"):
        user = User(id=username)
        login_user(user)
        return jsonify({"status": "logged_in"})
    return jsonify({"status": "unauthorized"}), 401

@app.route("/logout")
@login_required
def logout():
    logout_user()
    return redirect("/")

# --- Initialization ---
assistant_id = None

# --- Utilities ---
def load_projects():
    if os.path.exists(PROJECTS_FILE):
        with open(PROJECTS_FILE, "r") as f:
            return json.load(f)
    return {}

def save_projects(projects):
    with open(PROJECTS_FILE, "w") as f:
        json.dump(projects, f, indent=2)

@app.route("/")
@login_required
def index():
    return render_template("index.html")

@app.route("/init", methods=["POST"])
@login_required
def init():
    global assistant_id
    if not assistant_id:
        assistant = openai.beta.assistants.create(
            name="Jeeves",
            instructions=(
                "You are Jeeves — an expert in software development, creativity, and technology. "
                "You help users brainstorm ideas, debug code, generate software, track projects, integrate APIs, and recall past context."
            ),
            model="gpt-4-1106-preview",
            tools=[{"type": "code_interpreter"}, {"type": "file_search"}],
            metadata={"theme": "creativity_tech_coding"}
        )
        assistant_id = assistant.id
    return jsonify({"status": "initialized", "assistant_id": assistant_id})

@app.route("/chat", methods=["POST"])
@login_required
def chat():
    user_input = request.form.get("message")
    project_id = request.form.get("project_id")
    files = request.files.getlist("files")
    file_ids = []

    for f in files:
        if f:
            file_path = os.path.join(app.config['UPLOAD_FOLDER'], f.filename)
            f.save(file_path)
            upload = openai.files.create(file=open(file_path, "rb"), purpose="assistants")
            file_ids.append(upload.id)

    projects = load_projects()
    thread_id = projects[project_id]["thread_id"]

    openai.beta.threads.messages.create(
        thread_id=thread_id,
        role="user",
        content=user_input,
        file_ids=file_ids if file_ids else None
    )

    run = openai.beta.threads.runs.create(
        thread_id=thread_id,
        assistant_id=assistant_id
    )

    while True:
        run_status = openai.beta.threads.runs.retrieve(
            thread_id=thread_id,
            run_id=run.id
        )
        if run_status.status == "completed":
            break
        time.sleep(1)

    messages = openai.beta.threads.messages.list(thread_id=thread_id)
    assistant_response = next((m for m in messages.data if m.role == "assistant"), None)
    if assistant_response:
        return jsonify({"response": assistant_response.content[0].text.value})

    return jsonify({"response": "Something went wrong"}), 500

@app.route("/uploads/<filename>")
@login_required
def uploaded_file(filename):
    return send_from_directory(app.config['UPLOAD_FOLDER'], filename)

@app.route("/projects", methods=["GET", "POST", "PUT"])
@login_required
def projects():
    projects = load_projects()
    if request.method == "POST":
        data = request.get_json()
        project_id = str(uuid.uuid4())
        thread = openai.beta.threads.create()
        data["thread_id"] = thread.id
        projects[project_id] = data
        save_projects(projects)
        return jsonify({"status": "saved", "project_id": project_id, "thread_id": thread.id})
    elif request.method == "PUT":
        data = request.get_json()
        project_id = data.get("project_id")
        if project_id and project_id in projects:
            projects[project_id].update(data)
            save_projects(projects)
            return jsonify({"status": "updated", "project_id": project_id})
        return jsonify({"error": "Project not found"}), 404
    else:
        return jsonify(projects)

@app.route("/api/projects", methods=["GET"])
@login_required
def api_projects():
    return jsonify(load_projects())

@app.route("/api/project/<project_id>", methods=["GET"])
@login_required
def api_project_detail(project_id):
    projects = load_projects()
    return jsonify(projects.get(project_id, {}))

@app.route("/api/github_repo_info", methods=["POST"])
@login_required
def github_repo_info():
    data = request.get_json()
    repo_url = data.get("repo_url")
    if not repo_url:
        return jsonify({"error": "Missing repo_url"}), 400

    api_url = repo_url.replace("https://github.com/", "https://api.github.com/repos/")
    headers = {"Accept": "application/vnd.github.v3+json"}
    response = requests.get(api_url, headers=headers)
    return jsonify(response.json())

@app.route("/api/notion_pages", methods=["POST"])
@login_required
def notion_pages():
    data = request.get_json()
    page = notion.pages.create(parent={"database_id": data["database_id"]}, properties=data["properties"])
    return jsonify(page)

@app.route("/api/jira_ticket", methods=["POST"])
@login_required
def create_jira_ticket():
    data = request.get_json()
    auth = ("apikey", JIRA_API_TOKEN)
    headers = {"Content-Type": "application/json"}
    response = requests.post(JIRA_API_URL, auth=auth, headers=headers, json=data)
    return jsonify(response.json())

if __name__ == "__main__":
    app.run(debug=True)
