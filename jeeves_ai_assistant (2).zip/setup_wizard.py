import os

def write_env():
    print("🛠  First-Time Setup – Jeeves Assistant")
    env_vars = {
        "OPENAI_API_KEY": input("Enter your OpenAI API Key: "),
        "ADMIN_USERNAME": input("Create an admin username: "),
        "ADMIN_PASSWORD": input("Create an admin password: "),
        "APP_SECRET_KEY": input("Enter a secret key (or press Enter to autogenerate): ") or os.urandom(24).hex(),
    }

    optional = input("Would you like to configure Notion or Jira? (y/n): ")
    if optional.lower() == "y":
        env_vars["NOTION_API_KEY"] = input("Notion API Key: ")
        env_vars["JIRA_API_URL"] = input("Jira API URL: ")
        env_vars["JIRA_API_TOKEN"] = input("Jira API Token: ")

    with open(".env", "w") as f:
        for k, v in env_vars.items():
            f.write(f"{k}={v}\n")
    print("✅ .env file created. You can now run the app.")

if __name__ == "__main__":
    write_env()
